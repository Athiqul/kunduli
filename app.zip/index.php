<?php

$base_url="https://nukshatra.in";
require 'vendor/autoload.php';

require_once __DIR__ .'/route/web.php';

?>